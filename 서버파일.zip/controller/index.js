module.exports = {
    getViewControll: (req, res) => {
        res.render("index.html");
    }
}